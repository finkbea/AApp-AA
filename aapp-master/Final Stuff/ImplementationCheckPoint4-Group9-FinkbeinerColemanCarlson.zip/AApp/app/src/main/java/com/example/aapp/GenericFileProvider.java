package com.example.aapp;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
