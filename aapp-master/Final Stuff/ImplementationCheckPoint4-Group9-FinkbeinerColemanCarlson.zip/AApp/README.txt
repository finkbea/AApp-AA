AApp 

I'd recommend running our app by plugging a phone in rather than using the emulator but you can run it using the Android Studio emulator. It is currently only available through our Android Studio code. 

Navigating the app is very straightforward:

Resources provides links to other resources

Settings opens this file

The calendar lets you track when you've been drinking

The track your progress page provides a clearer view of your recent progress

Accountability buddy prompts you to keep in touch with up to three of your friends to hold you accountable. 
Accountability buddy page: added or removed friends are not updated on the dropdown until selecting a different buddy. 
